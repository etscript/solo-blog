title: Kubernetes Prometheus 监控方案快速部署(blackbox+wechat)
date: '2019-07-18 16:01:50'
updated: '2019-07-19 15:40:11'
tags: [ProjectNo.1]
permalink: /hello-prometheus
---
> 这应该是网上成功率比较高的一个监控方案的快速部署
以下部署具体到了详细的版本，部署很容易成功，但时间久了会导致版本有点落后
前提：你有一个Kubernetes环境了哦

### master 
> 创建PV、下载PV相关的部署yaml文件

```
# 注意：如果是按照系列教程安装过EFK的，这几步就不用重复了
git clone https://github.com/etscript/projectdriven.git
cd projectdriven/PVC
# 按照实际情况来修改deployment.yaml
# 192.168.122.1改为nfs server的ip
# /data/sys_data改为实际共享地址
kubectl apply -f service.yaml
kubectl apply -f class.yaml
kubectl apply -f deployment.yaml
```
>  验证PV大概可能是否成功

```
root@master:~/PVC# kubectl get sc
NAME                  PROVISIONER          AGE
managed-nfs-storage   my-nfs-provisioner   21d
```

> 创建prometheus和grafana的pvc

```
cd projectdriven/prometheus

# 这里面注意storage的大小，自己按需修改
kubectl create -f prometheus-data-pvc_create.yaml
# grafana非必须
kubectl create -f grafana-data-pvc_create.yaml
```

> 验证pvc创建是否成功

```
root@master:~# kubectl -n ns-monitor get pvc
NAME                  STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS          AGE
grafana-data-pvc      Bound    pvc-f5324622-9741-11e9-94b1-5254007d1968   80Gi       RWX            managed-nfs-storage   22d
prometheus-data-pvc   Bound    pvc-ffd78dd9-9741-11e9-94b1-5254007d1968   80Gi       RWX            managed-nfs-storage   22d
```
> 开始部署Prometheus

```
cd projectdriven/prometheus/config
kubectl create -f prometheus-conf.yaml
kubectl create -f prometheus-rules.yaml

kubectl create -f blackbox-conf.yaml
kubectl create -f alertmanager-conf.yaml
kubectl create -f wechat.template.yaml


cd projectdriven/prometheus
kubectl create -f prometheus-rbac.yaml
kubectl create -f prometheus.yaml
kubectl create -f node-exporter.yaml
kubectl create -f alertmanager.yaml
kubectl create -f blackbox.yaml

# 非必须
kubectl create -f grafana.yaml
```




> 到此Prometheus 监控方案快速部署完成
> 看到文章的最好进[博客](http://project-driven.xyz/hello-projectone)看文章哦，体验应该是最好的



