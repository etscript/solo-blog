title: Kubernetes 快速安装部署
date: '2019-07-16 13:37:42'
updated: '2019-07-19 19:24:15'
tags: [ProjectNo.1]
permalink: /hello-Kubernetes
---
> 这应该是网上成功率比较高的一个快速部署方案
以下部署具体到了详细的版本，部署很容易成功，但时间久了会导致版本有点落后

### master 和 slave
> 添加修改源

```
vim /etc/apt/sources.list

# deb cdrom:[Ubuntu 16.04 LTS _Xenial Xerus_ - Release amd64 (20160420.1)]/ xenial main restricted
deb-src http://archive.ubuntu.com/ubuntu xenial main restricted #Added by software-properties
deb http://mirrors.aliyun.com/ubuntu/ xenial main restricted
deb-src http://mirrors.aliyun.com/ubuntu/ xenial main restricted multiverse universe #Added by software-properties
deb http://mirrors.aliyun.com/ubuntu/ xenial-updates main restricted
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-updates main restricted multiverse universe #Added by software-properties
deb http://mirrors.aliyun.com/ubuntu/ xenial universe
deb http://mirrors.aliyun.com/ubuntu/ xenial-updates universe
deb http://mirrors.aliyun.com/ubuntu/ xenial multiverse
deb http://mirrors.aliyun.com/ubuntu/ xenial-updates multiverse
deb http://mirrors.aliyun.com/ubuntu/ xenial-backports main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-backports main restricted universe multiverse #Added by software-properties
deb http://archive.canonical.com/ubuntu xenial partner
deb-src http://archive.canonical.com/ubuntu xenial partner
deb http://mirrors.aliyun.com/ubuntu/ xenial-security main restricted
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-security main restricted multiverse universe #Added by software-properties
deb http://mirrors.aliyun.com/ubuntu/ xenial-security universe
deb http://mirrors.aliyun.com/ubuntu/ xenial-security multiverse

apt-get install -y apt-transport-https
curl https://mirrors.aliyun.com/kubernetes/apt/doc/apt-key.gpg | apt-key add -

cat <<EOF >/etc/apt/sources.list.d/kubernetes.list
deb https://mirrors.aliyun.com/kubernetes/apt/ kubernetes-xenial main
EOF

apt-get update
```
> 安装docker，kubernetes

`# 关闭Swap，机器重启后不生效 swapoff -a `
`# 修改/etc/fstab 永久关闭Swap`

```
apt-get install docker.io=18.09.7-0ubuntu1~16.04.4
apt-get install kubernetes-cni=0.6.0-00
apt-get install kubeadm=1.12.0-00 kubelet=1.12.0-00 kubectl=1.12.0-00
```
> 提前导入指定版本docker镜像

```
docker pull k8s.gcr.io/kube-controller-manager:v1.12.0
docker pull k8s.gcr.io/kube-apiserver:v1.12.0
docker pull k8s.gcr.io/kube-scheduler:v1.12.0
docker pull k8s.gcr.io/kube-proxy:v1.12.0
docker pull k8s.gcr.io/etcd:3.2.24
docker pull k8s.gcr.io/coredns:1.2.2
docker pull k8s.gcr.io/pause:3.1
```

### master 
> kubernetes master 初始化

```
kubeadm init

mkdir -p $HOME/.kube
cp -i /etc/kubernetes/admin.conf $HOME/.kube/config

kubectl apply -f "https://cloud.weave.works/k8s/net?k8s-version=$(kubectl version | base64 | tr -d '\n')"

# kubectl taint node master node-role.kubernetes.io/master:NoSchedule-

# (往master上调度)
```

### slave
> kubernetes slave节点加入

```
master上初始化的时候有下面这条命令

kubeadm join 172.30.81.69:6443 --token 1oavg9.35jc5db02ntw82ux --discovery-token-ca-cert-hash sha256:f68e58f0dbb50871102890bf57f7175ab8422ed34561ea22b544075e9e43c58a
```

### master
> kubernetes 是否部署成功

```
kubectl get pods --all-namespaces

root@master:~# kubectl get pods --all-namespaces
NAMESPACE     NAME                                      READY   STATUS    RESTARTS   AGE
kube-system   coredns-576cbf47c7-jwsbf                  1/1     Running   2          23d
kube-system   coredns-576cbf47c7-xhwwv                  1/1     Running   2          23d
kube-system   weave-net-266kh                           2/2     Running   0          23d
kube-system   weave-net-6xnff                           2/2     Running   2          23d
......
```

> 到此Kubernetes快速安装完成
衍生阅读有 Kubernetes 基本概念 核心原理 网络 存储 资源配额
> 看到文章的最好进[博客](http://project-driven.xyz/hello-projectone)看文章哦，体验应该是最好的



