title: Kubernetes 不大不小（项目No.1）
date: '2019-07-16 17:21:00'
updated: '2019-08-01 11:16:30'
tags: [ProjectNo.1]
permalink: /hello-projectone
---
> 什么样的项目适合用Kubernetes快速上线？

`现在的答案：抱歉啦，宝宝还小，宝宝也不知道，这个太不容易界定了`

[# 超适合小项目的 K8S 部署策略](https://zhuanlan.zhihu.com/p/46616763)
[# 不完美的 K8S 与阿里的解决之道](https://zhuanlan.zhihu.com/p/41601562)


> 先给不大不小的项目来个雏形吧！（索引如下）

1. [Kubernetes 快速安装部署](http://project-driven.xyz/hello-Kubernetes)
2. [NFS共享存储快速搭建](http://project-driven.xyz/hello-nfs)
3. [Kubernetes EFK日志收集方案](http://project-driven.xyz/hello-EFK)
4. [Kubernetes Prometheus 监控方案快速部署](http://project-driven.xyz/hello-prometheus)

>  来了解个大概

1. [Kubernetes 基础概念](http://project-driven.xyz/kubernetes-conception)
2. [Kubernetes 核心原理 --- Pod](http://project-driven.xyz/kubernetes-pod)
3. Kubernetes 网络
4. Kubernetes 存储
5. Kubernetes 资源配额

> 实在的部署一个应用

1. [来一个Flask Web 应用]()


> 看到文章的最好进[博客](http://project-driven.xyz/hello-projectone)看文章哦，体验应该是最好的