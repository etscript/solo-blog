title: Kubernetes 基础概念
date: '2019-07-19 21:27:23'
updated: '2019-07-19 21:33:27'
tags: [ProjectNo.1]
permalink: /kubernetes-conception
---
### 本文主要参考了以下几篇文章，将一些基础的概念整理了一下
[# Kubernetes架构](https://jimmysong.io/kubernetes-handbook/)
[# Kubernetes指南](https://legacy.gitbook.com/book/feisky/kubernetes)
[# 不完美的 K8S 与阿里的解决之道](https://zhuanlan.zhihu.com/p/41601562)

之前我们快速部署了Kubernetes，对于Kubernetes架构没有涉及，这里对基础架构整理一下：

1. 架构是个啥样子
2. 一般都有点啥、有啥用
3. 组件间大概的流程

### 1.  架构是个啥样子：

Kubernetes 大概的架构如下图了，Master+Slave（两个Node）：

![components.png](https://img.hacpai.com/file/2019/07/components-b480f1e9.png)


### 2.  一般都有点啥、有啥用：

* etcd 保存了整个集群的状态；
* kube-apiserver 提供了资源操作的唯一入口，并提供认证、授权、访问控制、API 注册和发现等机制；
* kube-controller-manager 负责维护集群的状态，比如故障检测、自动扩展、滚动更新等；
* kube-scheduler 负责资源的调度，按照预定的调度策略将 Pod 调度到相应的机器上；
* kubelet 负责维持容器的生命周期，同时也负责 Volume（CVI）和网络（CNI）的管理；
* Container runtime 负责镜像管理以及 Pod 和容器的真正运行（CRI），默认的容器运行时为 Docker；
* kube-proxy 负责为 Service 提供 cluster 内部的服务发现和负载均衡；
* kube-dns 负责为整个集群提供 DNS 服务

### 3. 组件间大概的流程

比如创建一个 Pod 的流程为：

1. 用户通过 REST API 创建一个 Pod
2. apiserver 将其写入 etcd
3. scheduluer 检测到未绑定 Node 的 Pod，开始调度并更新 Pod 的 Node 绑定
4. kubelet 检测到有新的 Pod 调度过来，通过 container runtime 运行该 Pod
5. kubelet 通过 container runtime 取到 Pod 状态，并更新到 apiserver 中

![workflow.png](https://img.hacpai.com/file/2019/07/workflow-55f5a38a.png)

`点到为止，不过度深入，想再了解可以看下开头提到的三篇文章`




> 看到文章的最好进[博客](http://project-driven.xyz/hello-projectone)看文章哦，体验应该是最好的

