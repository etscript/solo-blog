title: Kubernetes EFK日志收集方案
date: '2019-07-17 15:43:23'
updated: '2019-07-18 15:34:39'
tags: [ProjectNo.1]
permalink: /hello-EFK
---
* [ 2019.07.17，以下部署具体到了版本，部署很容易成功，但是会导致版本有点落后] 

### master 
> 下载PV相关的部署yaml文件

```
git clone https://github.com/etscript/projectdriven.git
cd projectdriven/PVC
# 按照实际情况来修改deployment.yaml
# 192.168.122.1改为nfs server的ip
# /data/sys_data改为实际共享地址
kubectl apply -f service.yaml
kubectl apply -f class.yaml
kubectl apply -f deployment.yaml
```
>  验证PV大概可能是否成功

```
root@master:~/PVC# kubectl get sc
NAME                  PROVISIONER          AGE
managed-nfs-storage   my-nfs-provisioner   21d
```

> 下载EFK相关的部署yaml文件

```
# 指定版本的yaml已经放在了git上
git clone https://github.com/etscript/projectdriven.git
cd projectdriven/EFK_yaml

# 如果要最新的版本，执行EFK_yaml中的get_new_yaml.sh覆盖已有yaml
# sh get_new_yaml.sh
```
> 开始安装部署EFK

```
# 注意点1：
# es-statefulset.yaml、fluentd-es-ds.yaml、kibana-deployment.yaml
# 三个文件中的
# nodeSelector:
#        kubernetes.io/hostname: es
# 记得需要修改成实际的node节点

# 注意点2：
# 前两个yaml文件中的storage记得修改成需要的大小

# 注意点3：
# 具体自定义fluentd-es-configmap.yaml下面会稍微详细说一下

kubectl create -f es-service.yaml -f es-statefulset.yaml
kubectl create -f fluentd-es-configmap.yaml -f fluentd-es-ds.yaml
kubectl create -f kibana-service.yaml -f kibana-deployment.yaml
```

> 检验EFK是否成功运行

```
# 查看组件是否都是running状态
root@master:~/EFK_yaml# kubectl get po -n kube-system
NAME                                      READY   STATUS    RESTARTS   AGE
elasticsearch-logging-0                   1/1     Running   0          5d22h
elasticsearch-logging-1                   1/1     Running   0          5d22h
fluentd-es-v2.5.2-4t28q                   1/1     Running   0          5d22h
fluentd-es-v2.5.2-4ttwz                   1/1     Running   0          5d22h
kibana-logging-6944bc569-5n7qt            1/1     Running   0          23d

# 直接游览器查看页面效果
# 先找到对应端口31806
root@master:~/EFK_yaml# kubectl get svc -n kube-system
NAME                    TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
elasticsearch-logging   NodePort    10.97.241.230    <none>        9200:31088/TCP   6d4h
kibana-logging          NodePort    10.104.165.160   <none>        5601:31806/TCP   23d

# 游览器输入master_ip:31806
```

> Fluentd 相关

```
# Mark 1、Fluentd 表达式编辑器 (http://fluentular.herokuapp.com/)
# 在线测试自己的Fluentd表达式是否正确

# Mark 2、官方网址 (https://docs.fluentd.org/)
# 大部分信息都能从这找到
```

> 看到文章的最好进[博客](http://project-driven.xyz/hello-projectone)看文章哦，体验应该是最好的

